import { Request, Response } from 'express';
import { db } from '../db';

export const getTasks = async (req: Request, res: Response) => {
  try {
    const [tasks] = await db.query('SELECT * FROM tasks');
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener las tareas', error });
  }
};

export const createTask = async (req: Request, res: Response) => {
  const { title, description, status, priority, due_date, project_id, employee_id } = req.body;
  try {
    const [result] = await db.query(
      'INSERT INTO tasks (title, description, status, priority, due_date, project_id, employee_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [title, description, status, priority, due_date, project_id, employee_id]
    );
    res.status(201).json({ id: (result as any).insertId, title, description, status, priority, due_date, project_id, employee_id });
  } catch (error) {
    res.status(500).json({ message: 'Error al crear la tarea', error });
  }
};

export const updateTask = async (req: Request, res: Response) => {
  const { id } = req.params;
  const { title, description, status, priority, due_date, project_id, employee_id } = req.body;
  try {
    await db.query(
      'UPDATE tasks SET title = ?, description = ?, status = ?, priority = ?, due_date = ?, project_id = ?, employee_id = ? WHERE task_id = ?',
      [title, description, status, priority, due_date, project_id, employee_id, id]
    );
    res.json({ id, title, description, status, priority, due_date, project_id, employee_id });
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar la tarea', error });
  }
};

export const deleteTask = async (req: Request, res: Response) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM tasks WHERE task_id = ?', [id]);
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar la tarea', error });
  }
};
