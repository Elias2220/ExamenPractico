export interface Task {
    id: number;
    name: string;
    projectId: number;
    employeeIds: number[];
  }
  