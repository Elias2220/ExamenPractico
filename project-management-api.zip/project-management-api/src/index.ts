import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import taskRoutes from './routes/taskRoutes';
import projectRoutes from './routes/projectRoutes';
import employeeRoutes from './routes/employeeRoutes';

const app = express();
const port = 3001;

app.use(cors());
app.use(bodyParser.json());

app.use('/api/tasks', taskRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/employees', employeeRoutes);

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
